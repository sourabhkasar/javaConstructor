package module5;

public class WrapperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="100";
		String str1="200";
		String str2="200.66";
		String str3="200.54";
		String str4="20.2";
		String str5="10.2";
		System.out.println("Total is "+(Float.parseFloat(str4)+Float.parseFloat(str5)));
		// 8  
		System.out.println("Total is "+(Integer.parseInt(str)+Integer.parseInt(str1)));
		System.out.println("total is "+(Double.parseDouble(str2)+Double.parseDouble(str3)));
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Short.MAX_VALUE);
		System.out.println(Integer.MAX_VALUE);
		
	}

}
