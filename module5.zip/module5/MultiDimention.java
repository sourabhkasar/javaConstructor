package module5;
import java.nio.file.spi.FileSystemProvider;
import java.util.Scanner;
public class MultiDimention {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int[][] arr=new int[3][4];
		System.out.println("enter 12 values");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				arr[i][j]=sc.nextInt();			}
		}
		System.out.println("rollno\t\tc++\t\tjava\t\tMySQL");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				System.out.print(arr[i][j]+"\t\t");			}
			System.out.println();
		}
		
	}

}
