package module5;

public class TestAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account1=new Account();
		System.out.println(account1);
		System.out.println("================================");
		Account account2=new Account(1, "sourabh", 50005);
		System.out.println(account2);
	}

}
