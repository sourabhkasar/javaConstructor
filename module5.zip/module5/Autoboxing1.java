package module5;

public class Autoboxing1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		Integer i=a;
		System.out.println("=================");
		int a1=i;//unboxing
	
	}

}
