package module5;

public class TestCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer1=new Customer();
//		customer1.setCustId(1);
//		customer1.setName("sourabh");
//		customer1.setAddress("at/post-sangvi");
//		customer1.setMobile(1224567896);
//		System.out.println("customer id is "+customer1.getCustId());
//		System.out.println("name is "+customer1.getName());
//		System.out.println("adreess is "+customer1.getAddress());
//		System.out.println("mobile is "+customer1.getMobile());
		System.out.println(customer1);
		
		System.out.println("======================================");
		Customer customer2=new Customer(18, "om", 78945612, "nashik");

		System.out.println("detail of second object");
//		System.out.println("customer id is "+customer2.getCustId());
//		System.out.println("name is "+customer2.getName());
//		System.out.println("adreess is "+customer2.getAddress());
//		System.out.println("mobile is "+customer2.getMobile());
		System.out.println(customer2);
	}

}
