package module5;
import java.util.Scanner;
public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter rollno,name,score");
		int rollNo=sc.nextInt();
		String name=sc.next();
		double score=sc.nextDouble();
		Student obj1=new Student();
		obj1.setName(name);
		obj1.setRollNo(rollNo);
		obj1.setScore(score);
		System.out.println("roll no is "+obj1.getRollNo());
		System.out.println("name is "+obj1.getName());
		System.out.println("score is "+obj1.getScore());
		//obj1.display();
		obj1.attendance();
		System.out.println("============================");
		Student obj2=new Student(61,"sourabh",11.5);
		obj2.setName("om");
	//	obj2.display();
		System.out.println("roll no is "+obj2.getRollNo());
		System.out.println("name is "+obj2.getName());
		System.out.println("score is "+obj2.getScore());
		obj2.attendance();
		System.out.println("=============================");
		System.out.println("changing the name");
		System.out.println("enter new name");
		String name1="pratik";
		obj2.setName(name1);
		System.out.println("new name is "+name1);
		
	}

}
